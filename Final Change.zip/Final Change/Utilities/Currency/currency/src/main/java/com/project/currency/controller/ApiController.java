package com.incture.currency.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.incture.currency.entities.Input;
import com.incture.currency.services.CurrencyConversion;

@RestController

public class ApiController {

	@Autowired
	CurrencyConversion cc;
	
	//@CrossOrigin(origins="http://localhost:5500")
//	@GetMapping("/")
//	public String getData()
//	{
//		//Input input=new Input("USD","INR");
//		System.out.println("xyz");
//		return "Hello brother";
//	}
	
	@PostMapping("/")
	public String postData(@RequestBody Input input) throws IOException
	{
		
		System.out.print(input.getFromCur());		
		cc.setInput(input);
		
		return cc.conversion();
		//return "hello";
		
	}
	
	

}
