package com.incture.currency.entities;

import org.springframework.stereotype.Component;


@Component
public class Input {
	
	private String fromCur;
	private String toCur;
	private double amount;
	

	public Input() {
		super();
	}

	public String getFromCur() {
		return fromCur;
	}

	public void setFromCur(String fromCur) {
		this.fromCur = fromCur;
	}

	public String getToCur() {
		return toCur;
	}

	public void setToCur(String toCur) {
		this.toCur = toCur;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Input(String fromCur, String toCur) {
		super();
		this.fromCur = fromCur;
		this.toCur = toCur;
	}

	public Input(String fromCur, String toCur, double amount) {
		super();
		this.fromCur = fromCur;
		this.toCur = toCur;
		this.amount = amount;
	}

}
