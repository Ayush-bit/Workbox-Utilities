package com.incture.currency.services;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.incture.currency.entities.Input;

@Component
public class CurrencyConversion {
	
	Input input;

	public void setInput(Input input) {
		this.input = input;
		System.out.println("input set");
	}

	public String conversion() throws IOException
	{

		String url_str = "https://v6.exchangerate-api.com/v6/53a1ed29eb98e1420e1c5757/latest/"+input.getFromCur();

		// Making Request
		URL url = new URL(url_str);
		HttpURLConnection request = (HttpURLConnection) url.openConnection();
		request.connect();

		// Convert to JSON
		
		JsonParser jp = new JsonParser();
		JsonElement root = jp.parse(new InputStreamReader((InputStream) request.getContent()));
		JsonObject jsonobj = root.getAsJsonObject();

		// Accessing object
		String req_result = jsonobj.get("result").getAsString();
		System.out.println(request.getContent());
		
		
		System.out.println(req_result);
		
		JsonObject job=(JsonObject) jsonobj.get("conversion_rates");
		String str=job.get(input.getToCur()).getAsString();
		
		//System.out.println(str);
		double d1=Double.parseDouble(str);
		d1=d1*input.getAmount();
		
		return String.valueOf(d1);
		
		
		
		
	}
	

}
