package com.inkathon.pojo2json.storagehelper;

import org.springframework.stereotype.Component;

@Component
public class Entity {
	
	public Entity() {
		super();
		// TODO Auto-generated constructor stub
	}
	private String packageName;
	private String fileName;
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Entity(String packageName, String fileName) {
		super();
		this.packageName = packageName;
		this.fileName = fileName;
	}
	public Entity(String packageName) {
		super();
		this.packageName = packageName;
	}
	
	
}
