package com.inkathon.pojo2json.restcontrol;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.inkathon.pojo2json.servicePro.ReverseServiceHandler;
import com.inkathon.pojo2json.servicePro.ServiceHandler;
import com.inkathon.pojo2json.storagehelper.Entity;
import com.inkathon.pojo2json.storagehelper.PojoStorage;
import com.inkathon.pojo2json.storagehelper.StorageHandler;



@RestController
@RequestMapping("/")
public class ApiControl {
	
	@Autowired
	ServiceHandler serviceHandler;
	
	@Autowired
	StorageHandler storageHandler;
	
	@Autowired
	ReverseServiceHandler reverseServiceHandler;
	
	@Autowired
	PojoStorage pojoStorage;
	
	
	private String packageName;
	private String fileName;
	private String jsonFile=null;
	
	
	@PostMapping("/input")
	public ResponseEntity<String> fileInput(@RequestBody  Entity entity)
	{
		
		this.packageName=entity.getPackageName();
		this.fileName=entity.getFileName();
		
		return ResponseEntity.ok("success");
	}
	
	@PostMapping("/upload")
	public ResponseEntity<String> postData(@RequestBody  String str)
	{
		
		System.out.println(str);
		
		if(packageName==null||fileName==null)
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("package Name or file name is empty");
		
		else if(str==null)
		{
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("input json string is empty");
		}
		else
		{
			try {
			       final ObjectMapper mapper = new ObjectMapper();
			       mapper.readTree(str);
			       String outputFile=serviceHandler.jsonToPojo(str,fileName,packageName);
			       
			       String url=ServletUriComponentsBuilder.fromCurrentContextPath()
							.path("/download/")
							.path(outputFile).toUriString();
							
				
			       return ResponseEntity.ok(url);
			       
			    } catch (IOException e) {
			       
			    	return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("invalid jason string");
			    }
			
			
		}
	}
	
	@PostMapping("upload/file")
	public ResponseEntity<String> postFile(@RequestParam("file") MultipartFile multipartFile)
	{
		System.out.println(multipartFile.getContentType());
		
		if(multipartFile.isEmpty())
		{
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("File is missing");
			
		}
		else if(!multipartFile.getContentType().equals("application/json")&&!multipartFile.getContentType().equals("application/zip")&&!multipartFile.getContentType().equals("text/x-java-source")&&!multipartFile.getContentType().equals("application/octet-stream"))
		{
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("only json file or java file allowed");
		}
		
		else if(multipartFile.getContentType().equals("text/x-java-source") || multipartFile.getContentType().equals("application/octet-stream"))
		{
			jsonFile=reverseServiceHandler.pojoToJsonConverter(multipartFile);
			
			String url=ServletUriComponentsBuilder.fromCurrentContextPath()
					.path("/downloadJson/").toUriString();
					
				return ResponseEntity.ok(url);
			
			
		}
		
		else if(multipartFile.getContentType().equals("application/zip")) {
			
			try {
				reverseServiceHandler.packageToJsonConverter(multipartFile);
			} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
					| IllegalArgumentException | InvocationTargetException | IOException | InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			String url=ServletUriComponentsBuilder.fromCurrentContextPath()
					.path("/downloadZip/").toUriString();
					
				return ResponseEntity.ok(url);
		}
		else 
		{
			String outputFile;
			
			if(packageName==null)
			{
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("File is missing");
			}
			else if(fileName==null)
			{
				outputFile=serviceHandler.jsonToPojo(multipartFile,packageName);
				
			}
			else {
				outputFile=serviceHandler.jsonToPojo(multipartFile,packageName,fileName);
			}
			
			String url=ServletUriComponentsBuilder.fromCurrentContextPath()
						.path("/download/")
						.path(outputFile).toUriString();
						
			
			return ResponseEntity.ok(url);
		}
		
	
		
		
	}
	
	@GetMapping("/downloadJson/")
	public void downloadJson(HttpServletResponse response)
	{
		response.setContentType("application/json");
		response.setHeader("Content-Disposition", "attachment; filename=\"outputJson.json\"");
		
		if(jsonFile!=null)
		{
			try {
				OutputStream outputStream=response.getOutputStream();
				outputStream.write(jsonFile.getBytes());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
	}
	
	@GetMapping("/downloadZip/")
	public void downloadZipFile(HttpServletResponse response)
	{
		response.setContentType("application/zip");
		response.setHeader("Content-Disposition", "attachment; filename=\"outputFile.zip\"");
		
		try {
			ZipOutputStream zipper=new ZipOutputStream(response.getOutputStream());
			pojoStorage.fileDownload(zipper);
			zipper.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@GetMapping("/download/{fileName}")
	public ResponseEntity<Resource> downloadFile(@PathVariable String fileName,HttpServletRequest request)
	{
		Resource resource = storageHandler.downloadFile(fileName);
        String mimeType;

        try {
            mimeType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
        } catch (IOException e) {
            mimeType = MediaType.APPLICATION_OCTET_STREAM_VALUE;
            
        }
        mimeType = mimeType == null ? MediaType.APPLICATION_OCTET_STREAM_VALUE : mimeType;

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(mimeType))
               .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;fileName="+resource.getFilename())
               .body(resource);
	}

}
