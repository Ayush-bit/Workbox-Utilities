package com.inkathon.pojo2json.storagehelper;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FilenameUtils;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import japa.parser.JavaParser;
import japa.parser.ParseException;
import japa.parser.ast.CompilationUnit;
import net.lingala.zip4j.ZipFile;



@Component
public class PojoStorage {


	Path filePath;
	Path path;
	String packageName;
	String packageDir=null;
	private Collection<File>fileArray=new ArrayList<>();


	public PojoStorage(@Value("${file.storage.location:temp}") String fileLocation)
	{
		filePath=Paths.get(fileLocation).toAbsolutePath().normalize();

		try {
			Files.createDirectories(filePath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException("Issue in creating file directory");
		}

	}

	public File pojoFileUpload(String fileName)
	{
		Path inputFilePath=Paths.get(filePath+"\\"+"input_file").toAbsolutePath();

		if(!Files.exists(inputFilePath))
		{
			try {
				Files.createDirectories(inputFilePath);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		inputFilePath=Paths.get(inputFilePath+"\\"+fileName);

		File file=new File(inputFilePath.toString());

		return file;

	}

	public Collection<File> fileUpload(MultipartFile multipartFile)
	{



		File zip=null;

		try {
			zip = File.createTempFile(UUID.randomUUID().toString(), "temp");
			FileOutputStream fileOutputStream = new FileOutputStream(zip);
		    IOUtils.copy(multipartFile.getInputStream(), fileOutputStream);
		    fileOutputStream.close();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		Path inputFilePath=Paths.get(filePath+"\\"+"input_file");
		String fileName=multipartFile.getOriginalFilename();



		if(!Files.exists(inputFilePath))
		{
			try {
				Files.createDirectories(inputFilePath);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	    try {

	         ZipFile zipFile = new ZipFile(zip);

	         zipFile.extractAll(inputFilePath.toAbsolutePath().toString());
	         zipFile.close();

	    } catch (IOException e) {
	        e.printStackTrace();
	    } finally {

	        zip.delete();
	    }



	    packageDir=FilenameUtils.removeExtension(fileName);
	    packageName=packageDir;

	    if(packageDir.contains("."))
	     packageDir= packageDir.replace(".", "\\");

		packageDir=Paths.get(inputFilePath+"\\"+packageDir).toAbsolutePath().toString();


		try {

			File pojoFiles=new File(packageDir);
			File fileList[]=pojoFiles.listFiles();


			for(File file:fileList)
			{

				if(file.getName().contains(".java"))
				{
					String content=Files.readString(Paths.get(file.getPath()));
					//content=content.replaceAll("\\b"+"package"+"\\b","//");
					//content=content.replace("package", "//");
					content=content.replaceAll("@", "//");
					//content=content.replace("private", "public");
					System.out.println(content);
					InputStream stream = new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8));
					CompilationUnit compilationUnit=null;
					try {
						compilationUnit = JavaParser.parse(stream);
						if(compilationUnit.getImports()!=null)
						compilationUnit.getImports().clear();


						Files.copy(new ByteArrayInputStream(compilationUnit.toString().getBytes(StandardCharsets.UTF_8)),Paths.get(file.getPath()) , StandardCopyOption.REPLACE_EXISTING);
						fileArray.add(file);

					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();

					}

				}



			}


		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		path=inputFilePath;

		//return inputFilePath;



		return fileArray;
	}

	public void fileDownload(ZipOutputStream zipper)
	{
		 ObjectMapper mapper=new ObjectMapper();
		 File inputPojoFiles=new File(packageDir);
			File classFilesArray[]=inputPojoFiles.listFiles();

			for(File fileList:classFilesArray)
			{

				if(fileList.getName().contains(".class"))
				{
					try (URLClassLoader classLoader = URLClassLoader.newInstance(new URL[] { new File(path.toUri()).toURI().toURL()})) {


						Class<?> example1Class = Class.forName(packageName+"."+FilenameUtils.removeExtension(fileList.getName()), true, classLoader);



						String jsonString;
						try {
							jsonString = mapper.writeValueAsString(example1Class.getDeclaredConstructor().newInstance());
							JsonNode jsonNode=mapper.readTree(jsonString);

							InputStream stream=new ByteArrayInputStream(jsonNode.toPrettyString().getBytes(StandardCharsets.UTF_8));
			                ZipEntry zipEntry = new ZipEntry(FilenameUtils.removeExtension(fileList.getName())+".json");
			                zipper.putNextEntry(zipEntry);
			                StreamUtils.copy(stream, zipper);
			                zipper.closeEntry();



						} catch (InstantiationException | IllegalAccessException | IllegalArgumentException
								| InvocationTargetException | NoSuchMethodException | SecurityException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}


					} catch (MalformedURLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}


			}

	}

}
