package com.inkathon.pojo2json.storagehelper;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

@Component
public class StorageHandler {
	
	private Path filePath;
	private Path outputPath;
	
	public StorageHandler(@Value("${file.storage.location:temp}") String fileLocation)
	{
		filePath=Paths.get(fileLocation).toAbsolutePath().normalize();
		
		try {
			Files.createDirectories(filePath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException("Issue in creating file directory");
		}
		
	}
	
	public Path fileUpload(MultipartFile multipartFile)
	{
		Path inputPath=Paths.get(filePath+"\\schema\\");
		String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
		
		try {
			
			if(!Files.exists(inputPath))
			{
				Files.createDirectories(inputPath);
			}
			inputPath=Paths.get(inputPath+"\\"+fileName);
			Files.copy(multipartFile.getInputStream(),inputPath , StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException("Issue in creating file directory");
		}
		System.out.println(inputPath);
		
		
		
		return inputPath;
		
		
	}
	
	public Path fileDownload()
	{
		System.out.println("hello");
		outputPath=Paths.get(filePath+"\\output_file\\");
		System.out.println(filePath);
		
		try {
			
			if(!Files.exists(outputPath))
			{
				Files.createDirectories(outputPath);
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException("Issue in creating file directory");
		}
		System.out.println(outputPath);
		
		return outputPath;
	}
	
	public Resource downloadFile(String outputFileName) {
		Path path=outputPath.toAbsolutePath().resolve(outputFileName);
		Resource resource;
		
		try {
            resource = new UrlResource(path.toUri());

        } catch (MalformedURLException e) {
           throw new RuntimeException("Issue in reading the file", e);
        }

        if(resource.exists() && resource.isReadable()){
            return resource;
        }else{
            throw new RuntimeException("the file doesn't exist or not readable");
        }
	}

}
