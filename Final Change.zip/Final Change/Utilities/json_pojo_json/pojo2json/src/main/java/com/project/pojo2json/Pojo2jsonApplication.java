22
		.package com.inkathon.pojo2json;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Pojo2jsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pojo2jsonApplication.class, args);
		
		

	}
	
	

}
