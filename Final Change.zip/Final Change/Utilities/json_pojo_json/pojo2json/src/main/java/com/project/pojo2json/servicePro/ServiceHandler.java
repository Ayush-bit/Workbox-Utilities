package com.inkathon.pojo2json.servicePro;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

import com.sun.codemodel.*;

import org.jsonschema2pojo.DefaultGenerationConfig;
import org.jsonschema2pojo.GenerationConfig;
import org.jsonschema2pojo.Jackson2Annotator;
import org.jsonschema2pojo.SchemaGenerator;
import org.jsonschema2pojo.SchemaMapper;
import org.jsonschema2pojo.SchemaStore;
import org.jsonschema2pojo.SourceType;
import org.jsonschema2pojo.rules.RuleFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;


import com.inkathon.pojo2json.storagehelper.StorageHandler;



@Component
public class ServiceHandler {

	@Autowired
	StorageHandler storageHandler;
	
	private String outputFile;

	public String jsonToPojo(MultipartFile multipartFile,String packageName) {
		
		Path inputPath=storageHandler.fileUpload(multipartFile);
		Path outputPath=storageHandler.fileDownload();
		
		//String packageName="com.pojofile";  
        File inputJson= new File(inputPath.toString());  
        File outputPojoDirectory=new File(outputPath.toString());  
        outputPojoDirectory.mkdirs();  
        try {  
        	convertJsonToJavaClass(inputJson.toURI().toURL(), outputPojoDirectory, packageName, inputJson.getName().replace(".json", "")); 
        	outputFile= packageZipper(packageName,outputPath.toString());
        } catch (IOException e) {  
             // TODO Auto-generated catch block  
             System.out.println("Encountered issue while converting to pojo: "+e.getMessage());  
             e.printStackTrace();  
        } 

        return outputFile;
	}
	
public String jsonToPojo(MultipartFile multipartFile,String packageName,String fileName) {
		
		Path inputPath=storageHandler.fileUpload(multipartFile);
		Path outputPath=storageHandler.fileDownload();
		//String packageName="com.pojofile";  
        File inputJson= new File(inputPath.toString());  
        File outputPojoDirectory=new File(outputPath.toString());  
        outputPojoDirectory.mkdirs();  
        try {  
        	convertJsonToJavaClass(inputJson.toURI().toURL(), outputPojoDirectory, packageName, fileName);
        	outputFile=packageZipper(packageName,outputPath.toString());
        } catch (IOException e) {  
             // TODO Auto-generated catch block  
             System.out.println("Encountered issue while converting to pojo: "+e.getMessage());  
             e.printStackTrace();  
        } 

        return outputFile;
	}
	
public String jsonToPojo(String jsonString,String fileName,String packageName) {
		
		
		Path outputPath=storageHandler.fileDownload();
		
          
        File outputPojoDirectory=new File(outputPath.toString());  
        outputPojoDirectory.mkdirs();  
        try {  
        	convertJsonToJavaClass(jsonString, outputPojoDirectory, packageName, fileName); 
        	System.out.println(outputPath.toString());
        	outputFile=packageZipper(packageName,outputPath.toString());
        } catch (IOException e) {  
             // TODO Auto-generated catch block  
             System.out.println("Encountered issue while converting to pojo: "+e.getMessage());  
             e.printStackTrace();  
        } 
        System.out.println("1");      
        return outputFile;

	}
	
	public void convertJsonToJavaClass(URL inputJsonUrl, File outputJavaClassDirectory, String packageName, String javaClassName) 
			  throws IOException {
			    JCodeModel jcodeModel = new JCodeModel();

			    GenerationConfig config = new DefaultGenerationConfig() {
			        @Override
			        public boolean isGenerateBuilders() {
			            return true;
			        }

			        @Override
			        public SourceType getSourceType() {
			            return SourceType.JSON;
			        }
			    };

			    SchemaMapper mapper = new SchemaMapper(new RuleFactory(config, new Jackson2Annotator(config), new SchemaStore()), new SchemaGenerator());
			   
				    mapper.generate(jcodeModel, javaClassName, packageName, inputJsonUrl);
			   

			    jcodeModel.build(outputJavaClassDirectory);
			}
	
	public void convertJsonToJavaClass(String inputJson, File outputJavaClassDirectory, String packageName, String javaClassName) 
			  throws IOException {
			    JCodeModel jcodeModel = new JCodeModel();

			    GenerationConfig config = new DefaultGenerationConfig() {
			        @Override
			        public boolean isGenerateBuilders() {
			            return true;
			        }

			        @Override
			        public SourceType getSourceType() {
			            return SourceType.JSON;
			        }
			    };

			    SchemaMapper mapper = new SchemaMapper(new RuleFactory(config, new Jackson2Annotator(config), new SchemaStore()), new SchemaGenerator());
			   
				    mapper.generate(jcodeModel, javaClassName, packageName, inputJson);
				    

			    jcodeModel.build(outputJavaClassDirectory);
			}

	public String packageZipper(String packageName,String outputDir) {
		
		
		String pack=packageName.replace(".", "\\");
		System.out.println(pack);
		Path root=Paths.get(pack);
		System.out.println(root);
		
		if(root.getParent()!=null)
		root=root.getParent();
		
		System.out.println(root);
		
		ZipFolder zipFolder = new ZipFolder();
		String outputFileName=packageName+".zip";
		String outputFileDir = outputDir+"\\"+root.toString();
        String outputZipDir = outputDir+"\\"+outputFileName;
        try {
			zipFolder.zipFolder(Paths.get(outputFileDir), Paths.get(outputZipDir));
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        
        return outputFileName;
		
	}
}
