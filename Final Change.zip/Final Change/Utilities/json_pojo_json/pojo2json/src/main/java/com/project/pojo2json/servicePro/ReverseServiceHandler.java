package com.inkathon.pojo2json.servicePro;



import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaCompiler.CompilationTask;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.inkathon.pojo2json.storagehelper.PojoStorage;

import japa.parser.JavaParser;
import japa.parser.ParseException;
import japa.parser.ast.CompilationUnit;

@Component
public class ReverseServiceHandler {

	@Autowired
	PojoStorage pojoStorage;


	public void packageToJsonConverter(MultipartFile multipartFile) throws IOException, ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException
	{

		Collection<File>colFile=pojoStorage.fileUpload(multipartFile);

		DiagnosticCollector<JavaFileObject> diagnosticCollector = new DiagnosticCollector<>();
		  JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
		  try (StandardJavaFileManager fileManager = compiler.getStandardFileManager(diagnosticCollector, null, null)) {
		    CompilationTask task = compiler.getTask(null, fileManager, diagnosticCollector, null, null, fileManager.getJavaFileObjectsFromFiles(colFile));
		    if(task.call())
		    System.out.println("Happy ending");


		  }


		}



		public String pojoToJsonConverter(MultipartFile multipartFile)
		{

			String result = null;
			JsonNode node = null;

			//System.out.println(FilenameUtils.removeExtension(multipartFile.getOriginalFilename()));
			File pojoFile=null;

			try {



				String content=new String(multipartFile.getBytes());

				content=content.replaceAll("\\b"+"package"+"\\b","//");
				content=content.replaceAll("@", "//");
				//content=content.replace("private", "public");
				System.out.println("***");
				System.out.println(content);
				System.out.println("***");
				InputStream stream = new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8));
				CompilationUnit compilationUnit = JavaParser.parse(stream);
				if(compilationUnit.getImports()!=null)
				compilationUnit.getImports().clear();
				stream=new ByteArrayInputStream(compilationUnit.toString().getBytes(StandardCharsets.UTF_8));
				//pojoFile=new File(compilationUnit.toString());

				pojoFile=pojoStorage.pojoFileUpload(multipartFile.getOriginalFilename());
				FileOutputStream fileOutputStream=new FileOutputStream(pojoFile);
				StreamUtils.copy(stream, fileOutputStream);

			} catch (IOException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println(pojoFile.getPath());

			DiagnosticCollector<JavaFileObject> diagnosticCollector=new DiagnosticCollector<>();
			JavaCompiler javaCompiler=ToolProvider.getSystemJavaCompiler();
			try (StandardJavaFileManager fileManager = javaCompiler.getStandardFileManager(diagnosticCollector, null, null)) {

			    List<String> tag = new ArrayList<>();
			    tag.add("-classpath");
			    tag.add("resources");
			    Iterable<? extends JavaFileObject> compilationUnit = fileManager.getJavaFileObjectsFromFiles(Arrays.asList(pojoFile));

			    	JavaCompiler.CompilationTask task = javaCompiler.getTask(null, fileManager, diagnosticCollector, tag, null, compilationUnit);

				    if (! task.call())
				        throw new IllegalStateException("compilation failed");

			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}


			ObjectMapper mapper=new ObjectMapper();

			try {
				URLClassLoader classLoader = URLClassLoader.newInstance(new URL[] { new File(pojoFile.getParent()).toURI().toURL()});
				Class<?> outputClass = Class.forName(FilenameUtils.removeExtension(pojoFile.getName()), true, classLoader);

				result=mapper.writeValueAsString(outputClass.getDeclaredConstructor().newInstance());

				node=mapper.readTree(result);


				//System.out.println(node.toPrettyString());

			} catch (MalformedURLException | ClassNotFoundException | JsonProcessingException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			return node.toPrettyString();

		}






}
