
public class TestSubject {
	
	private String name;
	private String class;

}
