package com.sample.app;


public class DemoEntity {

    private String name = "fishi";

    private Entity entity = new Entity();

    private int arr[];

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Entity getEntity() {
        return entity;
    }

    public void setEntity(Entity entity) {
        this.entity = entity;
    }

    public int[] getArr() {
        return arr;
    }

    public DemoEntity() {
        super();
    }

    public DemoEntity(String name, Entity entity, int[] arr) {
        super();
        this.name = name;
        this.entity = entity;
        this.arr = arr;
    }

    public void setArr(int[] arr) {
        this.arr = arr;
    }
}
