package com.sample.app;


//Component  
public class Entity {

    private String packageName = "Rahul";

    private String fileName = "xyz";

    public Entity() {
        super();
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Entity(String packageName, String fileName) {
        super();
        this.packageName = packageName;
        this.fileName = fileName;
    }

    public Entity(String packageName) {
        super();
        this.packageName = packageName;
    }
}
