package com.inkathon.pojo2json;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pojo2jsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
