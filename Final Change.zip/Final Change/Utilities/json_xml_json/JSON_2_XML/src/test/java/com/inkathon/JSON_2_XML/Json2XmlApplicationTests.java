package com.inkathon.JSON_2_XML;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Json2XmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
