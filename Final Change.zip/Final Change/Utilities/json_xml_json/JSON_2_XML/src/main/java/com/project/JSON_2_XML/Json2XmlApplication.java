package com.inkathon.JSON_2_XML;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Json2XmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(Json2XmlApplication.class, args);
	}

}
