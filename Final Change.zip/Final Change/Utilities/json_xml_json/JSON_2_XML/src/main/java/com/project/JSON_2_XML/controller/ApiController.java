package com.inkathon.JSON_2_XML.controller;

import java.io.IOException;
import java.nio.file.Path;

import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.xml.sax.SAXException;

import com.inkathon.JSON_2_XML.helper.Helper;
import com.inkathon.JSON_2_XML.services.ServiceProvider;


@RestController
public class ApiController {

	@Autowired
	ServiceProvider serviceProvider;

	@Autowired
	private Helper helper;


	@PostMapping("/upload")
	public ResponseEntity<String> fileUplod(@RequestParam("file-upload") MultipartFile multipartfile ) throws IOException, ParseException, TransformerException, ParserConfigurationException, SAXException
	{
		System.out.println(multipartfile.getContentType());
		//Validation
		if(multipartfile.isEmpty())
		{
			String x ="Request must contain a file" ;
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(x);
		}

		else if(!(multipartfile.getContentType().equals("application/json"))&&!(multipartfile.getContentType().equals("application/xml"))&&!(multipartfile.getContentType().equals("text/xml")))
		{

			String y ="Only json or xml file allowed as input" ;
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(y);
		}

		else if(multipartfile.getContentType().equals("application/json"))
		{


			Path path =serviceProvider.jsonToXml(multipartfile);
			String outputFileName=path.getFileName().toString();

			String url=ServletUriComponentsBuilder.fromCurrentContextPath()
					.path("/download/")
					.path(outputFileName)
					.toUriString();

			return ResponseEntity.ok(url);


		}
		else {

			Path path =serviceProvider.xmlToJson(multipartfile);
			String outputFileName=path.getFileName().toString();

			String url=ServletUriComponentsBuilder.fromCurrentContextPath()
					.path("/download/")
					.path(outputFileName)
					.toUriString();

			return ResponseEntity.ok(url);

		}




	}

	@GetMapping("/download/{fileName}")
    ResponseEntity<Resource> downLoadSingleFile(@PathVariable String fileName, HttpServletRequest request) {

        Resource resource = helper.downloadFile(fileName);
        String mimeType;

        try {
            mimeType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
        } catch (IOException e) {
            mimeType = MediaType.APPLICATION_OCTET_STREAM_VALUE;
        }
        mimeType = mimeType == null ? MediaType.APPLICATION_OCTET_STREAM_VALUE : mimeType;

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(mimeType))
               .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;fileName="+resource.getFilename())
               .body(resource);
    }

}
