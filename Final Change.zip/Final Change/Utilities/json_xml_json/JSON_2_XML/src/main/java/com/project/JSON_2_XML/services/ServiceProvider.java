package com.inkathon.JSON_2_XML.services;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.FilenameUtils;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.inkathon.JSON_2_XML.helper.Helper;

@Component
public class ServiceProvider {

	@Autowired
	Helper helper;

	public Path jsonToXml(MultipartFile multipartFile) throws IOException, ParserConfigurationException, SAXException, TransformerException
	{

		String inputDIR=helper.fileUpload(multipartFile).toString();
		String outputDIR=helper.downloadFilePath(multipartFile).toString();

		String content = new String(Files.readAllBytes(Paths.get(inputDIR)));
		JSONObject json = new JSONObject(content);

		//Convert a JSONObject to XML
	     String xmlText = XML.toString(json);
	     System.out.println(xmlText);

	     String str="<?xml version=\"1.0\" encoding=\"ISO-8859-15\"?>\n<"+"root"+">" + xmlText + "</"+"root"+">";
	     // Parse the given input
	     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	     DocumentBuilder builder = factory.newDocumentBuilder();
	     Document doc = builder.parse(new InputSource(new StringReader(str)));

	     //Write the parsed document to an xml file
	     TransformerFactory transformerFactory = TransformerFactory.newInstance();
	     Transformer transformer = transformerFactory.newTransformer();
	     transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	     transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

	     DOMSource source = new DOMSource(doc);


	     String outputFileName=FilenameUtils.removeExtension(multipartFile.getOriginalFilename());
	     outputDIR=outputDIR+"\\"+outputFileName+".xml";
	     StreamResult result =  new StreamResult(new File(outputDIR));
	     transformer.transform(source, result);
	     
		 Path path = Paths.get(outputDIR).toAbsolutePath().normalize();

		 return path;

	}

	public Path xmlToJson(MultipartFile multipartFile)
	{
		String inputDIR=helper.fileUpload(multipartFile).toString();
		String outputDIR=helper.downloadFilePath(multipartFile).toString();
		String content=null;
		String outputFileName=FilenameUtils.removeExtension(multipartFile.getOriginalFilename());
	     outputDIR=outputDIR+"\\"+outputFileName+".json";

		File file = new File(inputDIR);
		try {
			content = new String(Files.readAllBytes(Paths.get(file.toURI())));
			JSONObject jObj=XML.toJSONObject(content);
			FileWriter writer = new FileWriter(outputDIR);
            writer.write(jObj.toString(4));
            writer.close();

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		//Convert an XML to JSONObject
	      System.out.println(XML.toJSONObject(content));
	      Path path = Paths.get(outputDIR).toAbsolutePath().normalize();

		return path;

	}



}
