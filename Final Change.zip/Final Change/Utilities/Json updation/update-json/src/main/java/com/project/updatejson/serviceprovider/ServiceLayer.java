package com.inkathon.updatejson.serviceprovider;


import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.github.fge.jackson.jsonpointer.JsonPointer;
import com.github.fge.jackson.jsonpointer.JsonPointerException;
import com.github.fge.jsonpatch.diff.JsonDiff;

@Component
public class ServiceLayer {

	private String inputString=null;
	private String job;




	public String updateJson(String updateString)
	{
		ObjectMapper mapper = new ObjectMapper();
		if(job.equals("add"))
		{

			if(updateString!=null&&inputString!=null)
			{

				JsonNode root=null;
				JsonNode addKeys=null;

				try {
					addKeys = mapper.readTree(updateString);
					root = mapper.readTree(inputString);
					ObjectReader updater = mapper.readerForUpdating(root);

					updater.readValue(addKeys);
					System.out.println(root);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				inputString=root.toString();
				return root.toString();
			}
			else if(updateString!=null)
			{

				return updateString;
			}

			else return "input missing";

		}
		else
		{
			if(inputString!=null&&updateString!=null)
			{

				JsonNode root=null;
				JsonNode keyToRemove=null;
				try {
					 root = mapper.readTree(inputString);
					 keyToRemove = mapper.readTree(updateString);

					Iterator<String> iterator1=keyToRemove.fieldNames();
					Set<String> removeSet = new HashSet<>();
					
					JsonNode remnode=JsonDiff.asJson(root, keyToRemove);
					
					
					System.out.println(remnode.toString());

					while(iterator1.hasNext())
					{
						String str=iterator1.next();
						removeSet.add(str);

					}

					removeKeys(removeSet,root);

					System.out.println(root);


				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				inputString=root.toString();
				return root.toString();

			}

			else return "input is missing";

		}

	}


	public void removeKeys(Set<String> removeSet,JsonNode node) {


		Iterator<Map.Entry<String, JsonNode>> jsonField = node.fields();
		Set<String> keySet = new HashSet<>();


		while(jsonField.hasNext())
		{


			Map.Entry<String, JsonNode> map=jsonField.next();
			JsonNode jsonValue=null;
			String jsonKey=null;
			jsonValue=map.getValue();
			jsonKey=map.getKey();


			if(removeSet.contains(jsonKey))
			{

				keySet.add(jsonKey);

			}
			else if(jsonValue.isObject())
			{
				removeKeys(removeSet,jsonValue);



			}
			else if(jsonValue.isArray())
			{

				for(int i=0;i<jsonValue.size();i++)
				{
					removeKeys(removeSet,jsonValue.get(i));


				}
			}


		}



		for(String str:keySet)
		{
			ObjectNode object = (ObjectNode) node;
			object.remove(str);

		}


	}



//getter and setter
	public String getInputString() {
		return inputString;
	}

	public void setInputString(String inputString) {
		this.inputString = inputString;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

}
