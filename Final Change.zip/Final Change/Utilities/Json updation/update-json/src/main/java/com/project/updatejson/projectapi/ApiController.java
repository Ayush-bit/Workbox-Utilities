package com.inkathon.updatejson.projectapi;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.inkathon.updatejson.serviceprovider.ServiceLayer;

@RestController
public class ApiController {

	@Autowired
	ServiceLayer serviceLayer;

	OutputStream outputStream;
	InputStream inputStream;
	String outputFile;

	Resource resource;

	@PostMapping("/add")
	public ResponseEntity<String> addKeys(@RequestBody String keys){

		serviceLayer.setJob("add");
		outputFile=serviceLayer.updateJson(keys);
		return ResponseEntity.ok().body(outputFile);
	}

	@PostMapping("/remove")
	public ResponseEntity<String> removeKeys(@RequestBody String keys){

		serviceLayer.setJob("remove");
		outputFile=serviceLayer.updateJson(keys);
		return ResponseEntity.ok().body(outputFile);
	}

	@PostMapping("/upload")
	public ResponseEntity<String> jsonStringReader(@RequestBody String jsonString){


		//outputFile=serviceLayer.updateJson(jsonString);
		serviceLayer.setInputString(jsonString);

		return ResponseEntity.ok().body("Sucess");


	}
	@PostMapping("/upload/file")
	public ResponseEntity<String> jsonStringReader(@RequestParam("files") MultipartFile multipartFile){

		System.out.println(multipartFile.getContentType());
		if(multipartFile.isEmpty())
		{

			return ResponseEntity.status(HttpStatus.NO_CONTENT).body("file missing");
		}
		else if(!multipartFile.getContentType().equals("application/json"))
		{

			return ResponseEntity.status(HttpStatus.NO_CONTENT).body("wrong file type please upload json file");
		}
		else
		{
			
				String uploadFile=null;
				try {
					uploadFile = new String(multipartFile.getBytes(),StandardCharsets.UTF_8);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				serviceLayer.setInputString(uploadFile);

				return ResponseEntity.ok().body("Sucess");
		}


	}

    @GetMapping("/download")
    public StreamingResponseBody getSteamingFile(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setHeader("Content-Disposition", "attachment; filename=\"outputFile.json\"");
        inputStream=new ByteArrayInputStream(outputFile.getBytes());
        return outputStream -> {
            int nRead;
            byte[] data = new byte[1024*1024];
            while ((nRead = inputStream.read(data, 0, data.length)) != -1) {
                outputStream.write(data, 0, nRead);
            }
        };

    }



}


