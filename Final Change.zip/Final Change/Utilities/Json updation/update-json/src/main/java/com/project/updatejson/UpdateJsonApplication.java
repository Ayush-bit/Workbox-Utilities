package com.inkathon.updatejson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UpdateJsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(UpdateJsonApplication.class, args);
	}

}
