package com.inkathon.compare_json.servicelayer;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.github.fge.jsonpatch.diff.JsonDiff;

@Service
public class MyService {

	private Iterator<Entry<String, ArrayNode>> iterator;
	private Map<String,ArrayNode> index;


	public void compareJsonFile(MultipartFile[] multipartFiles)
	{
		ObjectMapper mapper=new ObjectMapper();



		try {

			index=new HashMap<>();



			for(int i=0;i<multipartFiles.length;i++)
			{
				JsonNode resultNode = null;

				for(int j=0;j<multipartFiles.length;j++)
				{
					if(i!=j)
					{

						JsonNode node1=mapper.readTree(multipartFiles[i].getBytes());
						JsonNode node2=mapper.readTree(multipartFiles[j].getBytes());
//						JsonPatch patch=JsonDiff.asJsonPatch(node1, node2);
						resultNode=JsonDiff.asJson(node1, node2);




						String num;
						num=Integer.toString(i)+"-"+Integer.toString(j);
						StringBuilder reverseNum=new StringBuilder();
						reverseNum.append(num);
						reverseNum.reverse();

						if(index.containsKey(num))
						{
							System.out.println("hello brother");
							ArrayNode arrayNode=mapper.createArrayNode();
							arrayNode=index.get(num).add(resultNode);
							index.remove(num);
							index.put(num, arrayNode);

						}
						else if(index.containsKey(reverseNum.toString()))
						{
							System.out.println("hello brother");
							ArrayNode arrayNode=mapper.createArrayNode();


							arrayNode=index.get(reverseNum.toString()).add(resultNode);
							index.remove(reverseNum.toString());
							index.put(reverseNum.toString(), arrayNode);
						}
						else
						{
							System.out.println("hello brother");
							ArrayNode arrayNode=mapper.createArrayNode();
							index.put(num, arrayNode.add(resultNode));
						}
					}

				}




			}


//			iterator = index.entrySet().iterator();
//
//			while(iterator.hasNext())
//			{
//				//System.out.println("hello brother");
//				 Entry<String, ArrayNode> pair = iterator.next();
//				 System.out.println(pair.getValue().toString());
//				 System.out.println(pair.getKey());
//
//			}


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}




	}

	public void downloader(ZipOutputStream zipper)
	{
		iterator = index.entrySet().iterator();

		while(iterator.hasNext())
		{
//			//System.out.println("hello brother");
			 Entry<String, ArrayNode> pair = iterator.next();
//			 System.out.println(pair.getValue().toString());
//			 System.out.println(pair.getKey());

			InputStream stream=new ByteArrayInputStream(pair.getValue().toPrettyString().getBytes(StandardCharsets.UTF_8));
			ZipEntry zipEntry=new ZipEntry(pair.getKey()+".json");
			try {
				zipper.putNextEntry(zipEntry);
				StreamUtils.copy(stream, zipper);
				zipper.closeEntry();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}



		}


	}


}
