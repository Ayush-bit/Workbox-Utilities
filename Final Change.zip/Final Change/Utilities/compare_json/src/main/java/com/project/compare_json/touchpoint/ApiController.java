package com.inkathon.compare_json.touchpoint;

import java.io.IOException;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.inkathon.compare_json.servicelayer.MyService;

@RestController
public class ApiController {

	@Autowired
	MyService myService;


	@PostMapping("/upload")
	public ResponseEntity<String> uploadFile(@RequestParam("files") MultipartFile[] files)
	{
		if(files.length<2)
		{
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Minimum two json file required");
		}

		for(MultipartFile file:files)
		{
			if(!file.getContentType().equals("application/json"))
			{
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Only json file accepted");
			}

		}

		myService.compareJsonFile(files);
		String url=ServletUriComponentsBuilder.fromCurrentContextPath()
				.path("/download").toUriString();


		return ResponseEntity.ok(url);

	}

	@GetMapping("/download")
	public void downloadFiles(HttpServletResponse response)
	{
		response.setContentType("application/zip");
		response.setHeader("Content-Disposition", "attachment; filename=\"outputFile.zip\"");

		try {
			ZipOutputStream zipOutputStream=new ZipOutputStream(response.getOutputStream());
			myService.downloader(zipOutputStream);
			zipOutputStream.close();


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

}
