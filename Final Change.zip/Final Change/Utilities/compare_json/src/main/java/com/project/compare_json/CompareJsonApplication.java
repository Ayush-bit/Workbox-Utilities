package com.inkathon.compare_json;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompareJsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompareJsonApplication.class, args);
	}

}
