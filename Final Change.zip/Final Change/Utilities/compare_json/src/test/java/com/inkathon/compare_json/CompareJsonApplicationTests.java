package com.inkathon.compare_json;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompareJsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
