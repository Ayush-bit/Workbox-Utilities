package com.incture.xls2pdf.controller;

import java.io.IOException;
import java.nio.file.Path;
import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.incture.xls2pdf.helper.Entity;
import com.incture.xls2pdf.helper.Helper;
import com.incture.xls2pdf.service.ServiceProvider;

@RestController
public class ApiController {

		@Autowired
		private ServiceProvider serviceProvider;

		@Autowired
		private Helper helper;

		private String inputFileExtention;
		private String outputFileExtention;

	@PostMapping("/file-ext")
	public String postData(@RequestBody Entity entity)
	{
		this.inputFileExtention=entity.getInputFileExtention().toLowerCase();
		this.outputFileExtention=entity.getOutputFileExtention().toLowerCase();
		System.out.println(inputFileExtention);
		System.out.println(outputFileExtention);
		return "successfully added";

	}

	@PostMapping("/file-upload")
	public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) throws InterruptedException, ExecutionException, IOException
	{

		System.out.println(file.getContentType());
		System.out.println(inputFileExtention);
		System.out.println(outputFileExtention);


		//Validation
		if(file.isEmpty())
		{
			String x ="Request must contain a file" ;
			//Resource resEmpty = new ByteArrayResource(x.getBytes());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(x);
		}



		else if(!file.getContentType().equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")&&!file.getContentType().equals("text/csv"))
		{
			 String y ="Only xlsx or csv file allowed" ;
				//Resource fileMissMatch = new ByteArrayResource(y.getBytes());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(y);

		}
		else if(inputFileExtention==outputFileExtention) {

			String z ="input and output are same type of file" ;
			//Resource fileMissMatch = new ByteArrayResource(z.getBytes());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(z);


		}
		else if(!outputFileExtention.equals("pdf")&&!outputFileExtention.equals("xlsx")&&!outputFileExtention.equals("csv"))
		{
			String a ="Wrong output file type" ;
			//Resource fileMissMatch = new ByteArrayResource(a.getBytes());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(a);

		}
		else if(!inputFileExtention.equals("xlsx")&&!inputFileExtention.equals("csv"))
		{
			String a ="Wrong input file type" ;
			//Resource fileMissMatch = new ByteArrayResource(a.getBytes());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(a);

		}
		 else
		 {

			Path path= serviceProvider.convert(file,inputFileExtention,outputFileExtention);
			String fileName=path.getFileName().toString();
			System.out.println(fileName);

			String url=ServletUriComponentsBuilder.fromCurrentContextPath()
					.path("/download/")
					.path(fileName)
					.toUriString();

			return ResponseEntity.ok(url);

		 }



	}

	@GetMapping("/download/{fileName}")
    ResponseEntity<Resource> downLoadSingleFile(@PathVariable String fileName, HttpServletRequest request) {

        Resource resource = helper.downloadFile(fileName);



        String mimeType;

        try {
            mimeType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
        } catch (IOException e) {
            mimeType = MediaType.APPLICATION_OCTET_STREAM_VALUE;
        }
        mimeType = mimeType == null ? MediaType.APPLICATION_OCTET_STREAM_VALUE : mimeType;

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(mimeType))
               .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;fileName="+resource.getFilename())
               .body(resource);
    }




}
