package com.incture.xls2pdf.service;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.ExecutionException;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.convertapi.client.Config;
import com.convertapi.client.ConvertApi;
import com.convertapi.client.Param;
import com.incture.xls2pdf.helper.Helper;

@Component
public class ServiceProvider {

	@Autowired
	private Helper helper;


	public Path convert(MultipartFile file,String inExt,String outExt) throws InterruptedException, ExecutionException, IOException
	{


		Path INPUT_DIR=helper.uploadFile(file);
		Path OUTPUT_DIR=helper.downloadFilePath(file);

		System.out.println(OUTPUT_DIR.toString());

			Config.setDefaultSecret("AHUMdcrQiLRand33");
			ConvertApi.convert(inExt,outExt,
			    new Param("File", Paths.get(INPUT_DIR.toString()))
			).get().saveFilesSync(Paths.get(OUTPUT_DIR.toString()));

			String str=FilenameUtils.removeExtension(file.getOriginalFilename());

			 Path path = OUTPUT_DIR.toAbsolutePath().resolve(str+"."+outExt);
			 return path;
	}

}
