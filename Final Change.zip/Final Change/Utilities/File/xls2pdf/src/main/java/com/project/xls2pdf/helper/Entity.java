package com.incture.xls2pdf.helper;

public class Entity {
	
	private String inputFileExtention;
	private String outputFileExtention;
	public String getInputFileExtention() {
		return inputFileExtention;
	}
	public void setInputFileExtention(String inputFileExtention) {
		this.inputFileExtention = inputFileExtention;
	}
	public String getOutputFileExtention() {
		return outputFileExtention;
	}
	public void setOutputFileExtention(String outputFileExtention) {
		this.outputFileExtention = outputFileExtention;
	}
	public Entity(String inputFileExtention, String outputFileExtention) {
		super();
		this.inputFileExtention = inputFileExtention;
		this.outputFileExtention = outputFileExtention;
	}
	

}
