package com.incture.xls2pdf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Xls2pdfApplicationTests {

	@Test
	void contextLoads() {
	}

}
